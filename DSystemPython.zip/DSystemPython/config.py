import os
basedir = os.path.abspath(os.path.dirname(__file__))

class Config:
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'hard to guess string'
    MAIL_SERVER = 'smtp.googlemail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    #MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'st0160711@gmail.com'
    MAIL_USERNAME = 'st0160711@gmail.com'
    #MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'jpc11116'
    MAIL_PASSWORD = 'jpc11116'
    MAIL_SUBJECT_PREFIX = 'Admin'
    MAIL_SENDER = 'st0160711@gmail.com'
    FLASKY_ADMIN = os.environ.get('FLASKY_ADMIN') 

    @staticmethod
    def init_app(app):
        pass

class DevelopmentConfig(Config):
    DEBUG = True




config = {
    
    'default': DevelopmentConfig
}
