#вспомогательный модуль очередей

class Queue:
     fr=0
     end=-1
     count=0 
     def __init__(self,size):
         self.size=size
         
         self.arrayQ=[0 for i in list(range(size))]
     def push(self,p):
         if self.end==self.size-1:
             self.end=-1
         
         self.end=self.end+1
         self.arrayQ[self.end]=p
             
             
         self.count=self.count+1
     def pop(self):
         if self.fr==self.size:
             self.fr=0
         
         tmp=self.arrayQ[self.fr]
         self.arrayQ[self.fr]=0    
         self.fr=self.fr+1
         self.count=self.count-1
         return tmp
     def get_size(self):
          return self.count
     def is_empty(self):
          return (self.count==0)

     def get_end(self):
          tmp=self.arrayQ[self.end]
          return tmp
          

