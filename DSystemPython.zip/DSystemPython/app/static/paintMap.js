
function paintMap(data) {


var points=new Array(80);

points[0]=[25,15,0];
points[1]=[55,25,1];
points[2]=[88,20,2];
points[3]=[120,35,3];
points[4]=[168,15,4];
points[5]=[200,37,5];
points[6]=[244,48,6];
points[7]=[290,20,7];
points[8]=[340,45,8];
points[9]=[400,20,9];
        
points[10]=[41,35,10];
points[11]=[76,63,11];
points[12]=[89,50,12];
points[13]=[123,73,13];
points[14]=[159,55,14];
points[15]=[206,67,15];
points[16]=[235,80,16];
points[17]=[270,68,17];
points[18]=[310,79,18];
points[19]=[370,65,19];
        
points[20]=[35,90,20];
points[21]=[60,135,21];
points[22]=[105,106,22];
points[23]=[152,110,23];
points[24]=[203,145,24];
points[25]=[240,168,25];
points[26]=[282,158,26];
points[27]=[312,171,27];
points[28]=[331,155,28];
points[29]=[371,140,29];
        
points[30]=[43,161,30];
points[31]=[65,182,31];
points[32]=[80,170,32];
points[33]=[110,185,33];
points[34]=[155,190,34];
points[35]=[225,201,35];
points[36]=[260,185,36];
points[37]=[326,196,37];
points[38]=[360,185,38];
points[39]=[410,200,39];

points[40]=[45,240,40];
points[41]=[80,250,41];
points[42]=[130,265,42];
points[43]=[170,245,43];
points[44]=[225,238,44];
points[45]=[284,254,45];
points[46]=[330,247,46];
points[47]=[380,252,47];
points[48]=[428,248,48];
points[49]=[481,256,49];

points[50]=[30,335,50];
points[51]=[85,334,51];
points[52]=[112,340,52];
points[53]=[143,365,53];
points[54]=[180,349,54];
points[55]=[219,340,55];
points[56]=[245,347,56];
points[57]=[300,338,57];
points[58]=[370,350,58];
points[59]=[436,330,59];

points[60]=[42,380,60];
points[61]=[78,374,61];
points[62]=[120,392,62];
points[63]=[167,382,63];
points[64]=[201,390,64];
points[65]=[258,379,65];
points[66]=[292,388,66];
points[67]=[320,397,67];
points[68]=[400,388,68];
points[69]=[446,394,69];

points[70]=[32,420,70];
points[71]=[63,430,71];
points[72]=[101,420,72];
points[73]=[156,440,73];
points[74]=[194,438,74];
points[75]=[235,432,75];
points[76]=[288,416,76];
points[77]=[325,421,77];
points[78]=[355,430,78];
points[79]=[400,440,79];

var ctx=document.getElementById('canvas').getContext     ('2d');
ctx.clearRect(0,0,500,500);

ctx.fillStyle="green";
ctx.beginPath();
ctx.arc((points[0][0]+Number(data)),(points[0][1]+Number(data)),5,0,2*Math.PI,true);
ctx.fill();
ctx.save();


ctx.strokeStyle="magenta";
ctx.lineWidth=1;
ctx.save();



for (var i=0;i<80;i++){


ctx.moveTo(points[i][0],points[i][1]);
if ((i<79) &&(((i+1)%10)!=0)) {
ctx.lineTo(points[i+1][0],points[i+1][1]);
ctx.stroke();
ctx.save();
  }
if (i<70){
ctx.moveTo(points[i][0],points[i][1]);
ctx.lineTo(points[i+10][0],points[i+10][1]);
ctx.stroke();
ctx.save();

}
 }



}
paintMap();
