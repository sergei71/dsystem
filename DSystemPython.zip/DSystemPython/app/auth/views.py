from flask import render_template, redirect, request, url_for, flash
from flask_login import login_user, logout_user, login_required, \
    current_user
from . import auth
from .. import db
from ..models import User
from ..email import send_email
from .forms import LoginForm, AdminForm,RegistrationForm
from pymongo import MongoClient
from ..distrib import find_doc
from werkzeug.security import generate_password_hash, check_password_hash

@auth.before_app_request
def before_request():
    if current_user.is_authenticated \
            and not current_user.confirmed \
            and request.endpoint \
            and request.endpoint[:5] != 'auth.' \
            and request.endpoint != 'static':
        return redirect(url_for('auth.unconfirmed'))


@auth.route('/unconfirmed')
def unconfirmed():
    if current_user.is_anonymous or current_user.confirmed:
        return redirect(url_for('main.index'))
    return render_template('auth/unconfirmed.html')


@auth.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        client=MongoClient('mongodb://localhost:27017')
        db=client['dsystem']
        x=list(db.users.find())
        y=find_doc(x,'email',form.email.data)
        
        y[0].pop('_id')
        print(y[0]) 
        user = User(**y[0])
        print(type(user.password_hash))
        if user is not None and user.verify_password(form.password.data):
            login_user(user, form.remember_me.data)
            return redirect(request.args.get('next') or url_for('main.view_order'))
        flash('Invalid username or password.')
    return render_template('auth/login.html', form=form)

@auth.route('/admin', methods=['GET', 'POST'])
def enter_admin():
    form = AdminForm()
    if form.validate_on_submit():
        if form.password.data=='abc':
            return redirect(url_for('main.admin_view'))
    return render_template('auth/admin.html',form=form)
        

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('main.index'))


@auth.route('/register', methods=['GET', 'POST'])
def register():
    form = RegistrationForm()
    if form.validate_on_submit():
        client=MongoClient('mongodb://localhost:27017')
        db=client['dsystem']
        user_id=0
        if len(list(db.users_id.find()))!=0:
            x=db.users_id.find()
            user_id=list(x)[0]['user_id']
        else:user_id=0
        db.users_id.delete_many({})
        db.users_id.insert({'user_id':user_id})
        username=form.username.data
        email=form.email.data
        password_hash=generate_password_hash(form.password.data)
        user = User(id=user_id,username=username,email=email,\
                    password_hash=str(password_hash))
        db.users.insert({'id':user_id,'username':username,'email':email,\
                         'password_hash':password_hash})
        
        token = user.generate_confirmation_token()
        send_email(form.email.data, 'Confirm Your Account',
                   'auth/email/confirm', user=user, token=token)
        flash('A confirmation email has been sent to you by email.')
        return redirect(url_for('auth.login'))
    return render_template('auth/register.html', form=form)


@auth.route('/confirm/<token>')
@login_required
def confirm(token):
    if current_user.confirmed:
        return redirect(url_for('main.index'))
    if current_user.confirm(token):
        flash('You have confirmed your account. Thanks!')
    else:
        flash('The confirmation link is invalid or has expired.')
    return redirect(url_for('main.index'))


@auth.route('/confirm')
@login_required
def resend_confirmation():
    token = current_user.generate_confirmation_token()
    send_email(current_user.email, 'Confirm Your Account',
               'auth/email/confirm', user=current_user, token=token)
    flash('A new confirmation email has been sent to you by email.')
    return redirect(url_for('main.index'))
