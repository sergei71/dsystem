﻿from flask import render_template, redirect,url_for
from . import main
from wtforms import TextAreaField
from wtforms import StringField
from flask_wtf import FlaskForm
from . forms import NameForm
import pika
from .. import db
from ..models import User
from pymongo import MongoClient
from threading import Thread
import os
from ..courier import Courier,get_list_nums
from random import random
import time

from ..maps import all_points,short_ways,shw,insert_db_ways
from ..distrib import auto_distrib,auto_transmit,find_doc,insert_order

#инициализация объектов курьеров
cour_1=Courier(24.5,15)
cour_2=Courier(25,15)
cour_3=Courier(25.5,15)
orders_data=[]

class MongoThread(Thread):
        def __init__(self):
            Thread.__init__(self)
        def run(self):
            os.system('mongod')

mongo_thr=MongoThread()
mongo_thr.start()

client=MongoClient('mongodb://localhost:27017')
db=client['dsystem']
orders=db['orders']
users=db['users']
ways=db['ways']
orders_id=db['orders_id']
users_id=db['users_id']
if db.ways.count()<6400:
    short_ways(all_points,shw)
    insert_db_ways(db)
a=list(db.ways.find())



@main.route('/')# стартовая страница
def index():
    
    return render_template('index2.html')

@main.route('/static/1')#вспомогательная функция,дающая данные для вывода сведений о заказах в таблицу на стр. админа
def view1():
    data=''
    if len(orders_data)>0:
        x=' '+';'
        data=x*12+str(orders_data)
        
    
    return data

@main.route('/admin')#страница администратора
def admin_view():
    return render_template('index3.html')



@main.route('/static/2')#вспомог. функция, выдающая данные о изменениях статуса заказов
def view2():
    stat_1=0
    stat_2=0
    stat_3=0
    
    if len(cour_1.points)!=0:
        cour_1.small_step()
        stat_1=cour_1.next_step()
        
                
    if len(cour_2.points)!=0:
        cour_2.small_step()
        stat_2=cour_2.next_step()
               
        
    if len(cour_3.points)!=0:
        cour_3.small_step()
        stat_3=cour_3.next_step()
                 
    
      
    data=str(cour_1.x)+';'+str(cour_1.y)+';'+str(cour_2.x)+';'\
          +str(cour_2.y)+';'+str(cour_3.x)+';'+str(cour_3.y)+';'\
          +str(get_list_nums(cour_1.points))+';'+str(get_list_nums(cour_2.points))+';'\
          +str(get_list_nums(cour_3.points))+';'+str(stat_1)+';'+str(stat_2)+';'\
          +str(stat_3)+';'+str(orders_data)
    #print(stat_1)      
    #print(str(cour_3.x))
    if stat_1!=0:
        db.orders.update_one({'id':stat_1},{'$set':{'status':'complete'}})
    if stat_2!=0:
        db.orders.update_one({'id':stat_2},{'$set':{'status':'complete'}})
    if stat_3!=0:
        db.orders.update_one({'id':stat_3},{'$set':{'status':'complete'}})
    print(stat_3)
            
    return data




@main.route('/order',methods=['GET','POST'])#функция представления стр. заказчика, с распределением заказов
def view_order():
    form=NameForm()
    
    #print(type(data))
    if form.validate_on_submit():
        data=form.name.data
        
        n=int(data)
        if len(list(db.orders_id.find()))!=0:
            x=db.orders_id.find()
            order_id=list(x)[0]['id']
        else:order_id=0
        order_id+=1
        db.orders_id.delete_many({})
        db.orders_id.insert({'id':order_id})
        num=auto_distrib(n,cour_1,cour_2,cour_3,a)
        auto_transmit(num,n,cour_1,cour_2,cour_3,a)
        insert_order(num,order_id,cour_1,cour_2,cour_3)
        print(num)
        print(order_id)
        print(cour_1.queue_ord.arrayQ[0])
        db.orders.insert_one({'id':order_id,'num_cour':num,'addr':n,'status':'process'})
        if len(orders_data)>0:
            count=orders_data[4]
        else: count=0
        count+=1
        orders_data.clear()
        orders_data.append(order_id)
        orders_data.append(num)
        orders_data.append(n)
        orders_data.append('process')
        orders_data.append(count)
        form.name.data=''
    return render_template('index1.html',form=form)




    
    
