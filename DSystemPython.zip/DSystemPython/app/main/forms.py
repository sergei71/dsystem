from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import Required
from threading import Thread
import time




                
class NameForm(FlaskForm):
    name = StringField('Enter address', validators=[Required()])
    submit = SubmitField('Submit')


    
