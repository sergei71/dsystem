
import time
from math import fabs
from math import sqrt
#from .maps import points as all_points
from .maps import Point, all_points
from .q import Queue



#класс курьера, передвигающегося по карте
class Courier():
    def __init__(self, x,y):
        self.x=x
        self.y=y
        self.points=[]
        self.queue_path=Queue(20)
        self.queue_ord=Queue(20)
        self.count_point=0
        self.xy_changed=False
        self.index=0
        self.old_x=0
        self.old_y=0
        self.new_x=0
        self.new_y=0
        self.cos=0
        self.sin=0
    
        self.next_point=0
    
        self.count_point=0
        
    

    def get_x(self):
        return self.x
    def get_y(self):
        return self.y
    def set_x(self,x):
        self.x=x
    def set_y(self,y):
        self.y=y

    

    def next_step(self):#метод, определяющий направление движения курьера по отрезку между двумя точками
        order_id=0
        if len(self.points)!=0:
            self.old_x=self.points[self.index].get_x()
            self.old_y=self.points[self.index].get_y()
            self.next_point=self.points[self.index+1]
            self.new_x=self.next_point.get_x()
            self.new_y=self.next_point.get_y()
            k=fabs((self.new_y-self.old_y)/(self.new_x-self.old_x))
            self.cos=sqrt(1/(1+k*k))
            self.sin=sqrt(k*k/(1+k*k))
           
            if fabs(self.new_x-self.x)<0.5 and fabs(self.new_y-self.y)<0.5:
                self.set_x(self.new_x)
                self.set_y(self.new_y)
                self.index=self.index+1
                self.count_point=self.count_point+1
                #self.xy_changed=True
            if self.index==len(self.points)-1:
                order_id=self.queue_ord.pop()
                self.count_point=0
                self.points.clear()
                self.index=0
                if not self.queue_path.is_empty():
                     self.points=self.queue_path.pop().list_points
            return order_id
   
            
            

            

    def small_step(self):#метод единичного смещения - "шаг"
        self.xy_changed=False
        dx=0
        dy=0
        
        
        
        if self.new_x>self.x:
            dx=1.0*self.cos
        if self.new_x<self.x:
            dx=-1.0*self.cos
        if self.new_y>self.y:
            dy=1.0*self.sin
        if self.new_y<self.y:
            dy=-1.0*self.sin
        self.x=self.x+dx
        self.y=self.y+dy 
     
    def get_num_point(self):#возвращает номер точки, рядом с которой находится курьер
          num=0
          x=self.get_x()
          y=self.get_y()
          for point in all_points:
               if fabs(x-point.x)<1.0 and fabs(y-point.y)<1.0:
                    num=point.num

          return num
                    
    def set_points(self,list_nums):#устанавливает маршрут курьера в виде списка номеров точек на карте
        points=[]
        for num in list_nums:
            p=Point(all_points[num].x,all_points[num].y,num)
            points.append(p)
        self.points=points



def get_list_nums(points):#возвращает список номеров точек 
    list_nums=[]
    for p in points:
        list_nums.append(p.num)
    return list_nums


            
        
def get_all_list_nums(points,queue_path):#возвращает список маршрутов в виде списков номеров точек
    all_list_nums=[]
    list_nums=get_list_nums(points)
    all_list_nums.append(list_nums)
    for i in range(queue_path.count):
        all_list_nums.append(get_list_nums(queue_path.arrayQ[i].list_points))
    return all_list_nums        
    

    
            
