# модуль, определяющий карту-схему и реализующий алгоритм кратчайших путей
from threading import Thread
import time
from math import sqrt, inf
from .q import Queue

class Point:
    def __init__(self,x,y,num):
        self.adj_pt=[]
        self.adj_edg=[]
        self.visited=False
        self.x=x
        self.y=y
        self.num=num

    def get_x(self):
        return self.x
    def get_y(self):
        return self.y

    def is_visited(self):
        return self.visited
    
    def set_visited(self,v):
        self.visited=v

    def get_adj_edg(self):
        for e in Map.all_edg:
            if self.num==e.either:
                p.adj_edg.add(e)
        
        return adj_edg

max_points=80
matrix=[[] for i in range(80)]#матрица смежности точек

'''for i in range(80):
    for j in range(80):
        if (j==i+1 or j==i-1 or j==i+10 or j==i-10 ):
            matrix[i].append(1)
        
        else:matrix[i].append(0)'''

for i in range(80):
    for j in range(80):
        if (j==i+1 or j==i-1 or j==i+10 or j==i-10 or j==i):
            matrix[i].append(1)
        
        else:matrix[i].append(0)

for i in range(80):
    for j in range(80):
        if i>8 and ((j==(i+1)and j%10==0) or (j==(i-1)and i%10==0)) :
            matrix[i][j]=0

#print(matrix[9])

shw=[[] for i in range(80)]
all_edg=[] #список ребер графа
all_adj_p=[[] for i in range(80)] #список смежности вершин
all_adj_e=[[] for i in range(80)] # список ребер, смежных с вершинами





all_points=[0 for i in list(range(80))] #инициализация списка точек с координатами
all_points[0]=Point(25,15,0)
all_points[1]=Point(55,25,1)
all_points[2]=Point(88,20,2)
all_points[3]=Point(120,35,3)
all_points[4]=Point(168,15,4)
all_points[5]=Point(200,37,5)
all_points[6]=Point(244,48,6)
all_points[7]=Point(290,20,7)
all_points[8]=Point(340,45,8)
all_points[9]=Point(400,20,9)
        
all_points[10]=Point(41,35,10)
all_points[11]=Point(76,63,11)
all_points[12]=Point(89,50,12)
all_points[13]=Point(123,73,13)
all_points[14]=Point(159,55,14)
all_points[15]=Point(206,67,15)
all_points[16]=Point(235,80,16)
all_points[17]=Point(270,68,17)
all_points[18]=Point(310,79,18)
all_points[19]=Point(370,65,19)
        
all_points[20]=Point(35,90,20)
all_points[21]=Point(60,135,21)
all_points[22]=Point(105,106,22)
all_points[23]=Point(152,110,23)
all_points[24]=Point(203,145,24)
all_points[25]=Point(240,168,25)
all_points[26]=Point(282,158,26)
all_points[27]=Point(312,171,27)
all_points[28]=Point(331,155,28)
all_points[29]=Point(371,140,29)
        
all_points[30]=Point(43,161,30)
all_points[31]=Point(65,182,31)
all_points[32]=Point(80,170,32)
all_points[33]=Point(110,185,33)
all_points[34]=Point(155,190,34)
all_points[35]=Point(225,201,35)
all_points[36]=Point(260,185,36)
all_points[37]=Point(326,196,37)
all_points[38]=Point(360,185,38)
all_points[39]=Point(410,200,39)

all_points[40]=Point(45,240,40)
all_points[41]=Point(80,250,41)
all_points[42]=Point(130,265,42)
all_points[43]=Point(170,245,43)
all_points[44]=Point(225,238,44)
all_points[45]=Point(284,254,45)
all_points[46]=Point(330,247,46)
all_points[47]=Point(380,252,47)
all_points[48]=Point(428,248,48)
all_points[49]=Point(481,256,49)

all_points[50]=Point(30,335,50)
all_points[51]=Point(85,334,51)
all_points[52]=Point(112,340,52)
all_points[53]=Point(143,365,53)
all_points[54]=Point(180,349,54)
all_points[55]=Point(219,340,55)
all_points[56]=Point(245,347,56)
all_points[57]=Point(300,338,57)
all_points[58]=Point(370,350,58)
all_points[59]=Point(436,330,59)

all_points[60]=Point(42,380,60)
all_points[61]=Point(78,374,61)
all_points[62]=Point(120,392,62)
all_points[63]=Point(167,382,63)
all_points[64]=Point(201,390,64)
all_points[65]=Point(258,379,65)
all_points[66]=Point(292,388,66)
all_points[67]=Point(320,397,67)
all_points[68]=Point(400,388,68)
all_points[69]=Point(446,394,69)

all_points[70]=Point(32,420,70)
all_points[71]=Point(63,430,71)
all_points[72]=Point(101,420,72)
all_points[73]=Point(156,440,73)
all_points[74]=Point(194,438,74)
all_points[75]=Point(235,432,75)
all_points[76]=Point(288,416,76)
all_points[77]=Point(325,421,77)
all_points[78]=Point(355,430,78)
all_points[79]=Point(400,440,79)




class Edge:# класс ребер
    def __init__(self,p1,p2):
        self.two_points=[]
        self.two_points.append(p1)
        self.two_points.append(p2)
        self.length=sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y))

    def get_length():
        return self.length

    def either(self):
        return self.two_points[0].num

    def other(self,p):
        if p==self.two_points[0].num:
            return self.two_points[1].num
        if p==self.two_points[1].num:
            return self.two_points[0].num

for i in range(len(all_points)):
    for j in range(len(all_points)):
        
        if matrix[i][j]==1:
            e=Edge(all_points[i],all_points[j])
            all_edg.append(e)


'''for e in all_edg:
    
    print(str(type(e.other(e.either())))+str(all_points[e.either()].num))'''

for i in range(len(all_points)):
    for e in all_edg:
        
        if i==e.either():
            
            all_points[i].adj_edg.append(e)
        all_adj_e.append(all_points[i].adj_edg)

'''for i in range(80):
     for e in all_points[i].adj_edg:
        print(e.either())'''


for i in range(len(all_points)):
    for e in all_points[i].adj_edg:
        #print(e.either())
        #print(type(e.other(e.either())))
        all_points[i].adj_pt.append(all_points[e.other(e.either())])
    all_adj_p.append(all_points[i].adj_pt)


class Path:#класс пути
    
    def __init__(self):
        self.list_points=[]
        self.list_edges=[]
        self.length=0
        for e in self.list_edges:
             self.length=self.length+e.length
    

    def get_length(self):
        self.length=0
        for e in self.list_edges:
            self.length=self.length+e.length
        return self.length

    def get_list_points(self):
        tmp=[]
        for e in self.list_edges:
            if e==self.list_edges[0]:
                tmp.append(all_points[e.either()])
                tmp.append(all_points[e.other(e.either())])
            else:
                tmp.append(all_points[e.other(e.either())])
        return tmp
    def set_list_points(self,list_nums):
        self.list_points.clear()
        for num in list_nums:
            p=all_points[num]
            self.list_points.append(p)
        
        print(type(self.list_points))
            

    def get_list_edges(self):
        tmp=[]
        for p in self.list_points:
            if self.list_points.index(p)==len(self.list_points)-1:
                break
            p_next=self.list_points[self.list_points.index(p)+1]
            e=Edge(p,p_next)
            tmp.append(e)
        return tmp










def sort(p):
    c=len(p.adj_edg)
    for i in range(c):
        for j in range(c-1):
            if p.adj_edg[i].length<p.adj_edg[j].length:
                k=p.adj_edg[i]
                p.adj_edg[i]=p.adj_edg[j]
                p.adj_edg[j]=k
'''p=Path()
a=[p for i in list(range(len(all_points)))]
shw=[a for i in list(range(len(all_points)))]'''
for i in range(80):
     for j in range(80):
          p=Path()
          shw[i].append(p)

for i in range(len(all_points)):
    for j in range(len(all_points)):
        
        if i!=j:shw[i][j].length=inf
        if i==j:shw[i][j].length=0          

for i in range(80):
    sort(all_points[i])

def short_ways(all_points,shw):#алгоритм поиска кратчайших путей
    points=all_points
    for i in range(len(points)):
        shw[i][i].length=0
        shw[i][i].list_points.append(all_points[i])
        shw[i][i].list_points.append(all_points[i])
        
        q=Queue(80)
        q.push(i)
        points[i].set_visited(True)
        while q.is_empty()==False:
            c=q.pop()
            #print(c)
            
            
            for e in points[c].adj_edg:
                v=e.other(c)
                #print(v)
                if points[v].is_visited()==False:
                    q.push(v)
                points[v].set_visited(True)
                tmp=Path()
                tmp.list_edges=shw[i][c].list_edges.copy()
                if shw[i][v].length>shw[i][c].length+e.length:
                   #print(shw[i][v].length)
                   shw[i][v].length=0
                   
                   tmp.list_edges.append(e)
                   shw[i][v].list_edges=tmp.list_edges.copy()
                   
                   shw[i][v].length=shw[i][v].get_length()
                   shw[i][v].list_points=shw[i][v].get_list_points()
        for i in range(len(points)):
            points[i].set_visited(False)


def get_list_nums(shw):
     z=[]
     for p in shw.list_points:
          z.append(p.num)
     return z
              
     
def insert_db_ways(db):
    for i in range(80):
        for j in range(80):
            list_nums=get_list_nums(shw[i][j])
            db.ways.insert({'start':i,'end':j,'list':list_nums})




