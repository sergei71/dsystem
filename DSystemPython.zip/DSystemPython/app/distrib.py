from threading import Thread
from pymongo import MongoClient
#from flask_mongoengine import MongoEngine, Document
import os
from .maps import Path
from math import sqrt

from .courier import Courier,get_list_nums, get_all_list_nums



def sort_min(a,b,c):
    num=0
    if min(a,b,c)==a:num=1
    if min(a,b,c)==b:num=2
    if min(a,b,c)==c:num=3
    return num

def find_doc(a,key,val):#вспомогательная функция для поиска документа в mongo
    l=[]
    for d in a:
        if d[key]==val:
            l.append(d)
    return l


def get_rest(cour,a):#вычисление остатка пути курьера
    rest=0
    rest_paths=0
    part=0
    part_path=0
    
    if len(cour.points)!=0:
        
        if cour.queue_path.is_empty()==False:
            
            q=cour.queue_path.arrayQ.copy()
            
            for i in range(cour.queue_path.count):
                
                path=Path()
                path.list_points=q[i].list_points
                path.list_edges=path.get_list_edges()
                rest_paths=rest_paths+path.get_length()
                

     
        
        count_point=cour.count_point
        x=cour.get_x()
        y=cour.get_y()
        num=cour.points[count_point+1].num
        n=cour.points[-1].num
        x_point=cour.points[count_point+1].x
        y_point=cour.points[count_point+1].y
        part=sqrt((x-x_point)*(x-x_point)+(y-y_point)*(y-y_point))
        p=Path()
        
        b=find_doc(a,'start',num)
        c=find_doc(b,'end',n)
        p.set_list_points(c[0]['list'])
        p.list_edges=p.get_list_edges()
        part_path=p.get_length()
        rest=part+rest_paths+part_path
    if len(cour.points)==0:rest=0
    
    return rest
    


def auto_distrib(n, cour_1, cour_2, cour_3,a): #функция, возвращающая номер
                                            #курьера для передачи нового заказа
    result=0
    rest_1=get_rest(cour_1,a)
    
    rest_2=get_rest(cour_2,a)
    
    rest_3=get_rest(cour_3,a)
    
    
    siz_1=len(cour_1.points)
    fin_1=0 #обозначение финальной точки текущего маршрута либо последнего в очереди
    if len(cour_1.points)==0:
        fin_1=cour_1.get_num_point()
    else:
        fin_1=cour_1.points[-1].num
        if cour_1.queue_path.is_empty()==False:
            
            fin_1=cour_1.queue_path.get_end().list_points[-1].num
            
            
    path_1=Path()
    
    b=find_doc(a,'start',fin_1)
    c=find_doc(b,'end',n)
    pts_1=c[0]['list']
    
    path_1.set_list_points(pts_1)
    
    path_1.list_edges=path_1.get_list_edges()
    path_1.get_length()
    
    

    siz_2=len(cour_2.points)
    fin_2=0 #обозначение финальной точки текущего маршрута либо последнего в очереди
    if len(cour_2.points)==0:
        fin_2=cour_2.get_num_point()
    else:
        fin_2=cour_2.points[-1].num
        if cour_2.queue_path.is_empty()==False:
            
            fin_2=cour_2.queue_path.get_end().list_points[-1].num
            
    path_2=Path()
    
    b=find_doc(a,'start',fin_2)
    c=find_doc(b,'end',n)
    pts_2=c[0]['list']
    
    path_2.set_list_points(pts_2)
    
    path_2.list_edges=path_2.get_list_edges()
    path_2.get_length()
    

    siz_3=len(cour_3.points)
    fin_3=0 #обозначение финальной точки текущего маршрута либо последнего в очереди
    if len(cour_3.points)==0:
        fin_3=cour_3.get_num_point()
    else:
        fin_3=cour_3.points[-1].num
        if cour_3.queue_path.is_empty()==False:
            
            fin_3=cour_3.queue_path.get_end().list_points[-1].num
            
            
    path_3=Path()
    
    b=find_doc(a,'start',fin_3)
    c=find_doc(b,'end',n)
    pts_3=c[0]['list']
    
    path_3.set_list_points(pts_3)
    
    path_3.list_edges=path_3.get_list_edges()
    path_3.get_length()
    

    distance_1=rest_1+path_1.get_length()
    distance_2=rest_2+path_2.get_length()
    distance_3=rest_3+path_3.get_length()
    
    result=sort_min(distance_1,distance_2,distance_3)
    return result

def auto_transmit(num,n,cour_1,cour_2,cour_3,a):#передача маршрута заказа курьеру
    
    #num=auto_distrib(n,cour_1,cour_2,cour_3,a)
    
    if num==1:
        if len(cour_1.points)==0:
            
            fin_1=cour_1.get_num_point()
            b=find_doc(a,'start',fin_1)
            c=find_doc(b,'end',n)
            cour_1.set_points(c[0]['list'])
            

        else:
            fin_1=cour_1.points[-1].num
            
            if cour_1.queue_path.is_empty()==False:
                
                fin_1=cour_1.queue_path.get_end().list_points[-1].num
                b=find_doc(a,'start',fin_1)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_1.queue_path.push(p)
                                
            else:
                
                b=find_doc(a,'start',fin_1)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_1.queue_path.push(p)
                
                                
    if num==2:
        if len(cour_2.points)==0:
            
            fin_2=cour_2.get_num_point()
            b=find_doc(a,'start',fin_2)
            c=find_doc(b,'end',n)
            cour_2.set_points(c[0]['list'])
            
        else:
            fin_2=cour_2.points[-1].num
            
            if cour_2.queue_path.is_empty()==False:
                
                fin_2=cour_2.queue_path.get_end().list_points[-1].num
                b=find_doc(a,'start',fin_2)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_2.queue_path.push(p)
                                
            else:
                
                b=find_doc(a,'start',fin_2)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_2.queue_path.push(p)
                
                


    if num==3:
        if len(cour_3.points)==0:
            
            fin_3=cour_3.get_num_point()
            b=find_doc(a,'start',fin_3)
            c=find_doc(b,'end',n)
            cour_3.set_points(c[0]['list'])
            

        else:
            fin_3=cour_3.points[-1].num
            
            if cour_3.queue_path.is_empty()==False:
                
                fin_3=cour_3.queue_path.get_end().list_points[-1].num
                b=find_doc(a,'start',fin_3)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_3.queue_path.push(p)
                                
            else:
                
                b=find_doc(a,'start',fin_3)
                c=find_doc(b,'end',n)
                pts=c[0]['list']
                
                p=Path()
               
                p.set_list_points(pts)
                
                cour_3.queue_path.push(p)

        
def insert_order(num,id,cour_1,cour_2,cour_3):#передача номера заказа курьеру
    if num==1:
        cour_1.queue_ord.push(id)
    elif num==2:
        cour_2.queue_ord.push(id)      
    elif num==3:
        cour_3.queue_ord.push(id)









    
    
                
'''def direct_transmit(cour):
    a=list(db.ways.find())
    b=find_doc(a,'start',fin_3)
    c=find_doc(b,'end',n)
    pts=c[0]['list']
    #cour.queue_path.push(pts) 
    cour.points=cour.set_points(c[0]['list'])'''


    




    
    

    
            
