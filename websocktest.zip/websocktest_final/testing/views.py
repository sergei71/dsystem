from django.shortcuts import render, render_to_response
from django.utils.safestring import mark_safe
import json
from django.http import HttpResponseRedirect
from django.http.response import HttpResponse
from random import random
from .models import Result, Test
from django.contrib.auth.models import User
from django.template import RequestContext


variant=[0]

def finding(a,expr):# вспомогательная ф-ция для нахождения индекса нужного элемента
    x=[]
    for i in range(len(dir(a))):
        if dir(a)[i].find(expr)!=-1:
            x.append(dir(a).index(dir(a)[i]))
    return x


def rand(z,test,num_quest):#для случайного расположения кнопки правильного ответа
        x=[]
        indexes=finding(test,'quest_')
        number=indexes[num_quest-2]
        quest_name=dir(test)[number]
        answ_true=test.__dict__[quest_name].split(';')[1]
        answ_false_1=test.__dict__[quest_name].split(';')[2]
        answ_false_2=test.__dict__[quest_name].split(';')[3]
        if z<1/3:
            x=[answ_true,answ_false_1,answ_false_2]
        if z<2/3 and z>1/3:
            x=[answ_false_1,answ_true,answ_false_2]
        if z>2/3:
            x=[answ_false_1,answ_false_2,answ_true]
        return x

def sort_results(results):# вспомогательная ф-ция
    for i in range(len(results)):
        for j in range(len(results)):
            if results[i].id<results[j].id:
                tmp=results[i]
                results[i]=results[j]
                results[j]=tmp
    return results

def index(request):
    from .consumers import test_var, started   
    username=request.session['username']
    user=User.objects.get(username=username)
    
    if request.GET:
        test=Test.objects.get(name=request.GET['r1'])
        test_var[0]=test.name
        variant[0]=test.name
        started=False
        result=Result(user_id=user.id,test_id=test.id,res_1='false', res_2='false',
                     res_3='false',res_4='false',res_5='false')
        result.save()
        return HttpResponseRedirect('/testing/'+request.GET['r1'])
    return render(request, 'testing/index.html', {})

def test(request, test_name):
    test=Test.objects.get(name=test_name)
    z=random()
    x=rand(z,test,1)
    
    
    return render(request, 'testing/test.html', {
        'test_name_json': mark_safe(json.dumps(test_name)),'x_0':x[0],'x_1':x[1],
        'x_2':x[2]})

def show_results(request):
    from .consumers import started, quest_num
    started[0]=False
    quest_num[0]=1
    return render(request,'testing/result.html')

def get_users(request):
    users=list(User.objects.all())
    usernames=[]
    for user in users:
        usernames.append(user.username)
    return HttpResponse(str(usernames))

def get_variant(request):
    
    global variant
    variant=dict(request.POST)['data']
    
    return HttpResponse('')

def get_report(request):
    
    global variant
    username=request.POST['data'][1:-1]
    user_id=User.objects.get(username=username).id
    results=[]
    if variant[0]=='all':
        res=list(Result.objects.filter(user_id=user_id))
        results=ready_res(res)
    if variant[0]=='last':
        res=list(Result.objects.filter(user_id=user_id))
        results=ready_res([res[-1]])
    results=str(results)
    if variant[0]=='win':
        res=list(Result.objects.all())
        results=win_results(res,username)
    
    return HttpResponse(results)



    



def count_corr(result):
    count=0
    for key in result:
        if result[key]=='True':
            count+=1
    return count

def win_results(results,name): #ф-ция для отбора списка результатов, где пользователь является победителем
    results=sort_results(results)
    res=[]
    for i in range(len(results)):
        username=results[i].user.username
        dump={'id':results[i].id,'user':username,'test':results[i].test.name,
                    'res_1':results[i].res_1,'res_2':results[i].res_2,
                'res_3':results[i].res_3,'res_4':results[i].res_4,
                'res_5':results[i].res_5, 'time_start':str(results[i].time_start)}
        res.append(dump)
    set_times=set()
    for i in range(len(res)):
        set_times.add(res[i]['time_start'])
    set_times=list(set_times)
    list_dicts=[{t:[],'counts':[[0,0]]} for t in set_times]
    for i in range(len(set_times)):
        for j in range(len(res)):
            if res[j]['time_start']==set_times[i]:
                list_dicts[i][set_times[i]].append(res[j])
    for i in range(len(set_times)):
        for j in range(len(list_dicts[i][set_times[i]])):
            count=count_corr(list_dicts[i][set_times[i]][j])
            entry=(j,count)
            if entry[1]>list_dicts[i]['counts'][0][1]:
                list_dicts[i]['counts'].pop()
                list_dicts[i]['counts'].append(entry)
    wins_list=[]
    for i in range(len(set_times)):
        coeff=list_dicts[i]['counts'][0][0]
        if list_dicts[i][set_times[i]][coeff]['user']==name:
            wins_list.append(list_dicts[i][set_times[i]][coeff])
    dumps_list=json.dumps(wins_list)
    return dumps_list

def ready_res(results): #ф-ция для формирования данных, содержащих все результаты пользователя
    results=sort_results(results)
    res=[]
    for i in range(len(results)):
        username=results[i].user.username
        dump={'id':results[i].id,'user':username,'test':results[i].test.name,
                    'res_1':results[i].res_1,'res_2':results[i].res_2,
                'res_3':results[i].res_3,'res_4':results[i].res_4,
                'res_5':results[i].res_5, 'time_start':str(results[i].time_start)}
        res.append(dump)
    dumps_list=json.dumps(res)
    return dumps_list
    
    
