from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from django.views import View
from .forms import UserLoginForm, UserRegistrationForm
from django.template import RequestContext
from django import forms
from django.contrib.auth.forms import UserCreationForm
from django.http import HttpResponseRedirect
from django.contrib.auth.views import login
import json

def enter(request):
    return HttpResponseRedirect('/accounts/')

def accounts(request):
    return render(request,'registration/accounts.html')

def login_view(request):
    username = request.POST.get('username', '')
    password = request.POST.get('password', '')
    user = authenticate(username=username, password=password)
    
    if user is not None and user.is_active:
        login(request, user)
        request.session['username']=user.username
        return HttpResponseRedirect("/testing/")
    else:
    #return HttpResponseRedirect("/accounts/login/")
        return render(request,'registration/login.html')
        

def register(request):
    context=RequestContext(request)
    if request.method=='POST':
        form=UserCreationForm(request.POST)
        if form.is_valid():
            new_user=form.save()
            return HttpResponseRedirect('/testing/')
    else:
        form=UserCreationForm()
    return render(request,'registration/register.html',{'form':form},context)


class LoginView(View):
    form_class = UserLoginForm
    template_name = 'forms.html'

    def get(self, request, *args, **kwargs):
        form = self.form_class
        return render(request, self.template_name, {'form': form, "title": "Login"})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        if form.is_valid():
            username = form.cleaned_data.get("username")
            password = form.cleaned_data.get("password")
            user = authenticate(username=username, password=password)
            login(request, user)
            return redirect('/')
        return render(request, self.template_name, {'form': form})


class RegistrationView(View):
    form_class = UserRegistrationForm
    template_name = 'forms.html'

    def get(self, request, *args, **kwargs):
        form = self.form_class
        return render(request, self.template_name, {'form': form, "title": "Registration"})

    def post(self, request, *args, **kwargs):
        form = self.form_class(request.POST)
        context=RequestContext(request)
        if form.is_valid():
            user = form.save(commit=False)
            password = form.cleaned_data.get("password")
            user.set_password(password)
            user.save()
            login(request, user)
            return redirect('/')
        return render(request, self.template_name, {'form': form, "title": "Registration"},context)
