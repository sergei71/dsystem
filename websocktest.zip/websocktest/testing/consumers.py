from asgiref.sync import async_to_sync
from channels.generic.websocket import WebsocketConsumer
import json
import time
from threading import Thread
from random import random
from .views import rand, sort_results
from django.contrib.auth.models import User
from .models import Result

quest_num=[1]#номер текущего вопроса
started=[False]#флаг - стартовал таймер или нет
test_var=[0]#вариант теста
thr=None

def finding(a):# вспомогательная ф-ция для нахождения индекса нужного элемента
    x=[]
    for i in range(len(dir(a))):
        if dir(a)[i].find('res_')!=-1:
            x.append(dir(a).index(dir(a)[i]))
    return x

class StoppingThread(Thread):#вспомогательный класс для запуска единого для всех таймера 
    
    def __init__(self,num,consumer):
        Thread.__init__(self)
        self.set_times=[1,10,10,10,10,10]
        self.num=num
        self.consumer=consumer
    def run(self):
        n=self.set_times.pop()
        while True:
            if n==7:
                z=random()
                x=rand(z)
                data=json.dumps({'res_label':''})
                async_to_sync(self.consumer.channel_layer.group_send)(
                        self.consumer.test_group_name,
                        {
                            'type': 'send_count_timer',
                            'data': data,
                            'username':self.consumer.scope['session']['username']
                        }
                    )
            
            if len(self.set_times)==0 and n<1 :
                
                break
            if self.num<quest_num[0]:
            
                self.num+=1
                
                
                if len(self.set_times)!=0:
                    n=self.set_times.pop()
                else:break 
                continue
                
                

            if n==0:
                self.num+=1
                quest_num[0]=self.num 
                if len(self.set_times)!=0:
                    n=self.set_times.pop()
                    z=random()
                    x=rand(z)
                    data=json.dumps({'quest_num':str(quest_num[0]),'res_label':'TIMEOUT',
                                     'answ_set':str(x),'hide':'show' })
                    
                    
                    async_to_sync(self.consumer.channel_layer.group_send)(
                        self.consumer.test_group_name,
                        {
                            'type': 'send_count_timer',
                            'data': data,
                            'username':self.consumer.scope['session']['username']
                        }
                    )
                else:break 
            
            else:
                data=json.dumps({'n':str(n)})
                
                async_to_sync(self.consumer.channel_layer.group_send)(
                        self.consumer.test_group_name,
                        {
                            'type': 'send_count_timer',
                            'data': data,
                            'username':self.consumer.scope['session']['username']
                        }
                )
                n-=1
                time.sleep(1)
                




            

class TestConsumer(WebsocketConsumer):# класс для получения, отправления по вебсокету и обработки данных
    
    
    
    def connect(self):
        
        self.test_name = self.scope['url_route']['kwargs']['test_name']
        self.test_group_name = 'test_%s' % self.test_name

        
        async_to_sync(self.channel_layer.group_add)(
            self.test_group_name,
            self.channel_name
            )
        
        self.accept()
        

    def disconnect(self, close_code):
        # Leave test group
        async_to_sync(self.channel_layer.group_discard)(
            self.test_group_name,
            self.channel_name
        )
        

    # Receive message from WebSocket
    def receive(self, text_data):
        
        text_data_json = json.loads(text_data)
        message = text_data_json['message']
        
        # Send message to room group
        global started
        
        if started[0]==False and test_var[0]:# запуск таймера
            
            thr=StoppingThread(1,self)
            thr.start()
            started[0]=True
        
        username=self.scope['session']['username']
        user_id=User.objects.get(username=username).id
            
        results=list(Result.objects.filter(user_id=user_id))
        
        if len(results)>1:
            result=sort_results(results)[-1]
        else:
            result=results[0]
        indexes=finding(result)
        
        if message=='true' and test_var[0]:
            
            if quest_num[0]<6:
                number=indexes[quest_num[0]-1]
                
                res_name=dir(result)[number]
                result.__dict__[res_name]=True
                result.save()
                quest_num[0]+=1           
        async_to_sync(self.channel_layer.group_send)(
            self.test_group_name,
            {
                'type': 'send_answer',
                'message': message,
                'username':self.scope['session']['username']
                
            }
        )

    # Receive message from room group
    def send_answer(self, event):
        message = event['message']
        
        # Send message to WebSocket
        x=None
        z=random()
        x=rand(z)
        text_data=None
        if event['username']==self.scope['session']['username']:
            if event['message']=='true':
                z=random()
                x=rand(z)
                text_data=None
                text_data=json.dumps({'message':message,'res_label':'SUCCESS!',\
                                      'answ_set':str(x),'quest_num':str(quest_num[0]),'hide':'show'})
                
            if event['message']=='false':
                text_data=json.dumps({'message':message,'res_label':'ERROR!','hide':'hide'})
                
        else:
            if event['message']=='true':
                
                text_data=None
                
                text_data=json.dumps({'message':message,'res_label':'YOU BEAT THE OPPONENT',\
                                      'answ_set':str(x),'quest_num':str(quest_num[0]),'hide':'show'})
                
                
            if event['message']=='false':
                text_data=json.dumps({'message':''})
        
                
        self.send(text_data)


    def send_count_timer(self, event):
        data = event['data'] 
        self.send(data)
    
        



        
