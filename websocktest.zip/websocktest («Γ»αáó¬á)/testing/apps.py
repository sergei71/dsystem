from django.apps import AppConfig


class TestingConfig(AppConfig):
    name = 'testing'
