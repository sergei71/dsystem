from django.db import models
from django.contrib.auth.models import User
from datetime import datetime

class Test(models.Model):
    name=models.CharField(max_length=64)
    quest_1=models.CharField(max_length=500)
    quest_2=models.CharField(max_length=500)
    quest_3=models.CharField(max_length=500)
    quest_4=models.CharField(max_length=500)
    quest_5=models.CharField(max_length=500)
    def __str__(self):
        return self.name


class Result(models.Model):
    user=models.ForeignKey(User, on_delete=models.CASCADE)
    test=models.ForeignKey(Test, on_delete=models.CASCADE)
    time_start=models.DateTimeField(default=datetime.now())
    res_1=models.CharField(max_length=30)
    res_2=models.CharField(max_length=30)
    res_3=models.CharField(max_length=30)
    res_4=models.CharField(max_length=30)
    res_5=models.CharField(max_length=30)
    
    
